import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "FreshClip Meat — Product Explorer",
  description: "Interactive 3D FreshClip Meat concept. A synthetic demonstration of sensing, comparator electronics and a visible colour indicator.",
  other: {
    "codex-preview": "development",
  },
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}
