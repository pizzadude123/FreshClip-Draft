import bpy, os, math
from mathutils import Vector
OUT=os.path.dirname(os.path.abspath(__file__))
bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.ops.import_scene.gltf(filepath=os.path.join(OUT,'..','public','models','freshclip.glb'))
assets=list(bpy.context.scene.objects)
for o in assets:
 if o.type=='MESH':
  for p in o.data.polygons:p.use_smooth=True
bpy.ops.mesh.primitive_plane_add(size=200,location=(0,0,-.07))
floor=bpy.context.object;floor.name='Studio floor'
m=bpy.data.materials.new('Warm neutral background');m.diffuse_color=(.8,.79,.75,1);floor.data.materials.append(m)
for name,loc,power,size in [('Key',(1,-5,8),950,6),('Fill',(-5,-2,4),700,5),('Rim',(3,4,6),1100,4)]:
 bpy.ops.object.light_add(type='AREA',location=loc);o=bpy.context.object;o.name=name;o.data.energy=power;o.data.shape='DISK';o.data.size=size;o.rotation_euler=(Vector((0,0,2))-o.location).to_track_quat('-Z','Y').to_euler()
bpy.ops.object.camera_add(location=(5.7,-10.6,5.2));cam=bpy.context.object;cam.name='Presentation camera';cam.rotation_euler=(Vector((0,0,2))-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO';cam.data.ortho_scale=5.6
scene=bpy.context.scene;scene.camera=cam;scene.render.engine='CYCLES';scene.cycles.device='CPU';scene.cycles.samples=32;scene.cycles.use_denoising=True
scene.world=bpy.data.worlds.new('Studio world');scene.world.use_nodes=True;scene.world.node_tree.nodes['Background'].inputs[0].default_value=(.8,.82,.86,1);scene.world.node_tree.nodes['Background'].inputs[1].default_value=.35
scene.render.resolution_x=1400;scene.render.resolution_y=1400;scene.render.resolution_percentage=100
scene.view_settings.view_transform='AgX';scene.render.image_settings.file_format='PNG'
for screen in bpy.data.screens:
 for area in screen.areas:
  if area.type=='VIEW_3D':area.spaces.active.region_3d.view_perspective='CAMERA'
bpy.ops.file.pack_all();bpy.ops.wm.save_as_mainfile(filepath=os.path.join(OUT,'freshclip.blend'))
scene.render.filepath=os.path.join(OUT,'exterior.png');bpy.ops.render.render(write_still=True)
for o in assets:
 if o.name.startswith('Shell'):o.location.z+=.95
cam.location=(4,-7,8);cam.rotation_euler=(Vector((0,0,2.7))-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.ortho_scale=5.8
scene.render.filepath=os.path.join(OUT,'internal.png');bpy.ops.render.render(write_still=True)
print('COMPLETE',len(assets),'imported objects')
