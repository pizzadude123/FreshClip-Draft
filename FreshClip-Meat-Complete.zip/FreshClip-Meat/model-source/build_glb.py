"""Portable deterministic GLB fallback. Coordinates authored Z-up, exported Y-up."""
import numpy as np, math, json, struct, os, random, io
from PIL import Image,ImageDraw,ImageFont
OUT=os.path.dirname(os.path.abspath(__file__));random.seed(31)
g={'asset':{'version':'2.0','generator':'FreshClip conceptual product asset'},'scene':0,'scenes':[{'nodes':[]}],'nodes':[],'meshes':[],'materials':[],'accessors':[],'bufferViews':[],'buffers':[],'images':[],'textures':[],'samplers':[{'magFilter':9729,'minFilter':9987,'wrapS':33071,'wrapT':33071}]};buf=bytearray();counts={}
def data(b):
 while len(buf)%4:buf.append(0)
 off=len(buf);buf.extend(b);g['bufferViews'].append({'buffer':0,'byteOffset':off,'byteLength':len(b)});return len(g['bufferViews'])-1
def acc(a,typ):
 a=np.array(a,dtype=np.float32);v=data(a.tobytes());entry={'bufferView':v,'componentType':5126,'count':len(a),'type':typ,'min':a.min(axis=0).tolist(),'max':a.max(axis=0).tolist()};g['accessors'].append(entry);return len(g['accessors'])-1
def mat(name,color,rough=.4,metal=0,alpha=1):
 d={'name':name,'pbrMetallicRoughness':{'baseColorFactor':[*color,alpha],'roughnessFactor':rough,'metallicFactor':metal},'doubleSided':True}
 if alpha<1:d['alphaMode']='BLEND'
 g['materials'].append(d);return len(g['materials'])-1
ivory=mat('Warm ivory polypropylene',(.83,.85,.81),.29);edge=mat('Seam and silicone gasket',(.16,.20,.17),.7);dark=mat('Charcoal marking',(.042,.064,.047),.65);green=mat('PCB solder mask',(.038,.20,.14),.52);metal=mat('Brushed battery steel',(.55,.58,.57),.28,.75);gold=mat('Copper traces',(.52,.34,.10),.34,.65);chip=mat('IC ceramic',(.045,.05,.045),.65);led=mat('Fresh indicator',(.20,.65,.28),.25);g['materials'][led]['emissiveFactor']=[.03,.16,.045];film=mat('Food bag translucent polyethylene',(.78,.85,.80),.19,0,.13);seam=mat('Bag sealed edges',(.64,.76,.68),.4,0,.31);meatmat=mat('Meat',(.46,.115,.13),.68);fat=mat('Subtle marbling',(.73,.48,.43),.72)
def mesh(name,vertices,faces,ma,component=None,normals=None,uv=None):
 counts[name]=counts.get(name,0)+1;name=name if counts[name]==1 else name+'.'+str(counts[name]-1).zfill(3)
 v=np.array(vertices,dtype=float);tri=[]
 for f in faces:
  for i in range(1,len(f)-1):tri.append([f[0],f[i],f[i+1]])
 tri=np.array(tri)
 if normals is None:
  normals=np.zeros(v.shape)
  for a,b,c in tri:
   n=np.cross(v[b]-v[a],v[c]-v[a]);normals[a]+=n;normals[b]+=n;normals[c]+=n
  normals/=np.maximum(np.linalg.norm(normals,axis=1)[:,None],1e-10)
 else:normals=np.array(normals)
 v=v[:,[0,2,1]];v[:,2]*=-1;normals=normals[:,[0,2,1]];normals[:,2]*=-1
 attrs={'POSITION':acc(v[tri.flatten()],'VEC3'),'NORMAL':acc(normals[tri.flatten()],'VEC3')}
 if uv is not None:attrs['TEXCOORD_0']=acc(np.array(uv)[tri.flatten()],'VEC2')
 g['meshes'].append({'name':name,'primitives':[{'attributes':attrs,'material':ma}]});node={'name':name,'mesh':len(g['meshes'])-1,'extras':{'component':component or ''}};g['nodes'].append(node);g['scenes'][0]['nodes'].append(len(g['nodes'])-1)
def box(name,loc,dims,ma,bevel=.08,component=None):
 h=np.array(dims)/2;rr=min(bevel,min(h)*.99);inner=h-rr;verts=[];norms=[];faces=[]
 # Each side sampled at corner transitions, yielding a true rounded box.
 vals=[]
 for d in range(3):
  vals.append(sorted(set([-h[d],-inner[d],inner[d],h[d]]+[float(sign*(inner[d]+rr*math.sin(i*math.pi/12))) for sign in [-1,1] for i in range(7)])))
 for axis in range(3):
  other=[a for a in range(3) if a!=axis]
  for sign in [-1,1]:
   off=len(verts);va,vb=vals[other[0]],vals[other[1]]
   for a in va:
    for b in vb:
     p=np.zeros(3);p[axis]=sign*h[axis];p[other]=[a,b];q=np.minimum(np.maximum(p,-inner),inner);n=p-q;n/=max(np.linalg.norm(n),1e-9);verts.append(q+rr*n+loc);norms.append(n)
   for i in range(len(va)-1):
    for j in range(len(vb)-1):
     k=off+i*len(vb)+j;f=[k,k+len(vb),k+len(vb)+1,k+1]
     a,b,c=[np.array(verts[t]) for t in f[:3]]
     if np.dot(np.cross(b-a,c-a),norms[k])<0:f.reverse()
     faces.append(f)
 mesh(name,verts,faces,ma,component,norms)
def cyl(name,loc,r,depth,ma,component=None,rotation=None):
 v=[];faces=[];nr=48
 for z,rad in [(-depth/2,r*.94),(-depth/2+.01,r),(depth/2-.01,r),(depth/2,r*.94)]:
  for i in range(nr):
   a=i*2*math.pi/nr;p=np.array([math.cos(a)*rad,math.sin(a)*rad,z]);
   if rotation:
    ax,ay,az=rotation
    for axis,ang in enumerate([ax,ay,az]):
     if ang:
      inds=[j for j in range(3) if j!=axis];c,s=math.cos(ang),math.sin(ang);x,y=p[inds];p[inds]=[c*x-s*y,s*x+c*y]
   v.append(p+loc)
 for j in range(3):
  for i in range(nr):faces.append([j*nr+i,j*nr+(i+1)%nr,(j+1)*nr+(i+1)%nr,(j+1)*nr+i])
 faces.extend([list(range(nr-1,-1,-1)),list(range(3*nr,4*nr))]);mesh(name,v,faces,ma,component)
def curve(name,pts,ma,r=.008):
 v=[];faces=[]
 for i,p in enumerate(pts):
  t=np.array(pts[min(i+1,len(pts)-1)])-np.array(pts[max(i-1,0)]);t/=max(np.linalg.norm(t),1e-9);u=np.cross(t,[0,1,0]);u/=max(np.linalg.norm(u),1e-9);w=np.cross(t,u)
  for j in range(8):v.append(np.array(p)+r*(math.cos(j*math.pi/4)*u+math.sin(j*math.pi/4)*w))
 for i in range(len(pts)-1):
  for j in range(8):faces.append([i*8+j,i*8+(j+1)%8,(i+1)*8+(j+1)%8,(i+1)*8+j])
 mesh(name,v,faces,ma)
def text(name,words,loc,size,ma,rot=(math.pi/2,0,0)):
 font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',80);bb=font.getbbox(words);w=bb[2]+8;h=100;im=Image.new('RGBA',(w,h),(0,0,0,0));col=tuple(int(x*255) for x in g['materials'][ma]['pbrMetallicRoughness']['baseColorFactor'][:3]);ImageDraw.Draw(im).text((0,-bb[1]),words,font=font,fill=(*col,255));b=io.BytesIO();im.save(b,format='PNG');g['images'].append({'bufferView':data(b.getvalue()),'mimeType':'image/png'});g['textures'].append({'source':len(g['images'])-1,'sampler':0});tx=mat(name+' ink',(1,1,1),.8);g['materials'][tx]['alphaMode']='BLEND';g['materials'][tx]['pbrMetallicRoughness']['baseColorTexture']={'index':len(g['textures'])-1}
 ww=w/80*size;hh=h/80*size;xx,yy,zz=loc
 if rot==(0,0,0):v=[(xx,yy,zz),(xx+ww,yy,zz),(xx+ww,yy+hh,zz),(xx,yy+hh,zz)]
 else:v=[(xx,yy,zz-hh*.5),(xx+ww,yy,zz-hh*.5),(xx+ww,yy,zz+hh*.5),(xx,yy,zz+hh*.5)]
 mesh(name,v,[(0,1,2,3)],tx,uv=[(0,1),(1,1),(1,0),(0,0)])
# Reuse the canonical component definitions directly.
src=open(os.path.join(OUT,'build_model.py')).read();section=src[src.index('# Lower fixed'):src.index('# Bag with')];exec(section)
section=src[src.index('verts=[];faces=[];nx='):src.index("mesh=bpy.data.meshes.new('Bag draped film')")];exec(section);mesh('Packaging',verts,faces,film,'packaging')
section=src[src.index('# Thin seals'):src.index("mesh=bpy.data.meshes.new('Steak solid')")];exec(section)
# Replace faceted extrusion with softly tapered organic rings.
v=[];f=[];N=72
for scale,y in [(.82,-.32),(.98,-.27),(1,-.15),(1,.13),(.96,.23),(.80,.28)]:
 for x,z in cont:v.append((x*scale,y,1.06+z*scale))
for j in range(5):
 for i in range(N):f.append([j*N+i,j*N+(i+1)%N,(j+1)*N+(i+1)%N,(j+1)*N+i])
f.extend([list(range(N-1,-1,-1)),list(range(5*N,6*N))]);mesh('Meat',v,f,meatmat,'meat')
section=src[src.index('# Several vein-like'):src.index('# Save render studio')];exec(section.replace('-.304','-.324'))
# GLB container.
g['buffers']=[{'byteLength':len(buf)}];js=json.dumps(g,separators=(',',':')).encode();js+=b' '*((-len(js))%4);buf.extend(b'\0'*((-len(buf))%4));total=12+8+len(js)+8+len(buf)
with open(os.path.join(OUT,'freshclip.glb'),'wb') as f:f.write(struct.pack('<III',0x46546c67,2,total));f.write(struct.pack('<II',len(js),0x4e4f534a));f.write(js);f.write(struct.pack('<II',len(buf),0x004e4942));f.write(buf)
with open(os.path.join(OUT,'mesh-index.json'),'w') as f:json.dump(g['nodes'],f,indent=2)
print('Exported',len(g['meshes']),'meshes;',total,'bytes')
