"""FreshClip Meat — conceptual industrial-design asset. Run with Blender or bpy.
Dimensions and architecture are demonstration assumptions, not a validated device.
"""
import bpy, math, random, os, json
from mathutils import Vector
OUT=os.path.dirname(os.path.abspath(__file__))
bpy.ops.object.select_all(action='SELECT'); bpy.ops.object.delete(use_global=False)
random.seed(31)
def mat(name,color,rough=.4,metal=0,alpha=1):
 m=bpy.data.materials.new(name);m.diffuse_color=(*color,alpha);m.use_nodes=True
 p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(*color,alpha);p.inputs['Roughness'].default_value=rough;p.inputs['Metallic'].default_value=metal;p.inputs['Alpha'].default_value=alpha
 if alpha<1:
  m.surface_render_method='DITHERED';m.use_transparency_overlap=False
 return m
ivory=mat('Warm ivory polypropylene',(.83,.85,.81),.29)
edge=mat('Seam and silicone gasket',(.16,.20,.17),.7)
dark=mat('Charcoal marking',(.042,.064,.047),.65)
green=mat('PCB solder mask',(.038,.20,.14),.52)
metal=mat('Brushed battery steel',(.55,.58,.57),.28,.75)
gold=mat('Copper traces',(.52,.34,.10),.34,.65)
chip=mat('IC ceramic',(.045,.05,.045),.65)
led=mat('Fresh indicator',(.20,.65,.28),.25)
p=led.node_tree.nodes.get('Principled BSDF');p.inputs['Emission Color'].default_value=(.1,.55,.19,1);p.inputs['Emission Strength'].default_value=.3
film=mat('Food bag translucent polyethylene',(.78,.85,.80),.19,0,.15)
film.node_tree.nodes.get('Principled BSDF').inputs['Coat Weight'].default_value=.4
seam=mat('Bag sealed edges',(.64,.76,.68),.4,0,.31)
meatmat=mat('Meat',(.46,.115,.13),.68)
fat=mat('Subtle marbling',(.73,.48,.43),.72)
def finish(o,name,material,component=None):
 o.name=name;o.data.materials.append(material)
 if component:o['component']=component
 return o
def box(name,loc,dims,ma,bevel=.08,component=None):
 bpy.ops.mesh.primitive_cube_add(size=1,location=loc);o=bpy.context.object;o.dimensions=dims;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
 if bevel:
  mod=o.modifiers.new('Soft molded edges','BEVEL');mod.width=bevel;mod.segments=4
  bpy.context.view_layer.objects.active=o;bpy.ops.object.modifier_apply(modifier=mod.name)
 mod=o.modifiers.new('Weighted normals','WEIGHTED_NORMAL');bpy.ops.object.modifier_apply(modifier=mod.name)
 return finish(o,name,ma,component)
def cyl(name,loc,r,depth,ma,component=None,rotation=None):
 bpy.ops.mesh.primitive_cylinder_add(vertices=48,radius=r,depth=depth,location=loc);o=bpy.context.object
 if rotation:o.rotation_euler=rotation
 be=o.modifiers.new('Edge fillet','BEVEL');be.width=.018;be.segments=3;bpy.ops.object.modifier_apply(modifier=be.name)
 for p in o.data.polygons:p.use_smooth=True
 return finish(o,name,ma,component)
def text(name,words,loc,size,ma,rot=(math.pi/2,0,0)):
 bpy.ops.object.text_add(location=loc,rotation=rot);o=bpy.context.object;o.data.body=words;o.data.size=size;o.data.extrude=.0003;o.data.space_character=1.05;o.data.align_y='CENTER';o.data.materials.append(ma);bpy.ops.object.convert(target='MESH');o=bpy.context.object;o.name=name;return o
def curve(name,pts,ma,r=.008):
 c=bpy.data.curves.new(name,'CURVE');c.dimensions='3D';c.bevel_depth=r;c.bevel_resolution=2;s=c.splines.new('POLY');s.points.add(len(pts)-1)
 for p,co in zip(s.points,pts):p.co=(*co,1)
 o=bpy.data.objects.new(name,c);bpy.context.collection.objects.link(o);o.data.materials.append(ma);bpy.context.view_layer.objects.active=o;o.select_set(True);bpy.ops.object.convert(target='MESH');o.select_set(False);return o
# Lower fixed chassis plus slender rear jaw: bag throat lies between y=-.04 and .04.
box('Clamp_Base',(0,0,3.19),(3.65,.91,.17),ivory,.075,'clamp')
box('Clamp_RearJaw',(0,.34,2.98),(3.59,.20,.43),ivory,.08,'clamp')
box('Clamp_FrontJaw',(0,-.30,3.005),(3.6,.23,.37),ivory,.07,'clamp')
box('Clamp_Gasket',(0,.01,3.065),(3.37,.065,.26),edge,.02,'clamp')
# Body walls remain while lid is removed; component well open above.
box('Housing_Front',(0,-.43,3.47),(3.64,.15,.51),ivory,.06,'housing')
box('Housing_Back',(0,.43,3.47),(3.64,.13,.51),ivory,.06,'housing')
for x in [-1.75,1.75]:box('Housing_End', (x,0,3.47),(.16,.78,.51),ivory,.05,'housing')
box('Shell_Top',(0,0,3.77),(3.66,.94,.19),ivory,.085,'housing')
for x in [-1.60,1.60]:cyl('Shell_Fastener',(x,.28,3.87),.036,.01,metal,'housing')
# Board and deliberately readable architecture.
box('PCB',(0,0,3.32),(3.18,.69,.065),green,.035,'pcb')
cyl('Battery_Holder',(-1.02,.02,3.38),.325,.10,dark,'battery')
cyl('Battery_CR2032',(-1.02,.02,3.45),.30,.10,metal,'battery')
text('Battery_Marking','CR2032',(-1.24,-.025,3.505),.076,dark,(0,0,0))
box('Battery_Contact',(-1.02,.23,3.515),(.25,.11,.028),metal,.015,'battery')
box('Comparator',(0,0,3.415),(.40,.36,.115),chip,.018,'control')
for side in [-1,1]:
 for i in range(5):box('Control_Pin',(-.16+i*.08,side*.22,3.375),(.036,.12,.025),metal,.005,'control')
text('Control_Marking','CTRL',(-.14,-.05,3.478),.076,ivory,(0,0,0))
box('Temperature_Sensor',(.53,.19,3.408),(.21,.17,.08),chip,.02,'temperature')
box('VOC_Sensor',(.98,.10,3.43),(.38,.35,.16),metal,.045,'sensor')
# Closed probe inlet routes downward on inner package side into headspace.
box('Sensor_Inlet',(.98,.10,3.02),(.26,.24,.72),ivory,.055,'sensor')
box('Sensor_Membrane',(.98,-.027,2.76),(.17,.025,.19),dark,.018,'sensor')
for i in range(4):box('Sensor_Grille',(.918+i*.041,-.042,2.76),(.013,.009,.16),metal,.003,'sensor')
for i in range(3):box('Passive',(-.5+i*.2,.2,3.39),(.105,.08,.04),chip,.007,'pcb')
for j in range(3):curve('PCB_Trace',[(.9,.1-j*.09,3.357),(.4,.1-j*.09,3.357),(.35,-.15-j*.06,3.357),(.12,-.15-j*.06,3.357)],gold,.009)
curve('PCB_Power',[(-.68,0,3.357),(-.45,0,3.357),(-.45,-.2,3.357),(-.24,-.2,3.357)],gold,.011)
# Exterior brand and indicator fascia: readable in frontal view.
text('Brand','FreshClip',(-1.53,-.514,3.54),.24,dark)
text('Brand_Subtitle','M E A T',(-1.51,-.515,3.335),.074,dark)
box('Indicator_Bezel',(.82,-.519,3.525),(1.10,.09,.25),edge,.075,'indicator')
box('Indicator',(.82,-.571,3.525),(.94,.035,.15),led,.06,'indicator')
text('Indicator_Caption','F R E S H N E S S',(.30,-.514,3.335),.061,dark)
cyl('Reset_Button',(1.52,-.526,3.49),.066,.06,dark,'button',(math.pi/2,0,0))
for x in [-1.55,1.55]:cyl('Hinge',(x,.43,3.06),.12,.30,metal,'clamp',(0,math.pi/2,0))
# Bag with varying depth, bowed front and rear, gathered upper throat.
# All dimensions are illustrative, roughly 100 mm clip width.
verts=[];faces=[];nx=26;nz=28
for side in [-1,1]:
 for j in range(nz+1):
  t=j/nz;z=.18+t*3.0
  width=1.45*(.91+.09*math.sin(t*math.pi)) if t<.8 else 1.45*(1-(t-.8)*.65)
  for i in range(nx+1):
   u=-1+2*i/nx;x=u*width
   depth=.46*math.sin(math.pi*t*.97)**.7*(1-.7*abs(u)**4)
   if t>.78:depth*=max(.06,1-(t-.78)/.22)
   ripple=.022*math.sin(u*53+t*13)*math.sin(t*math.pi)+.013*math.cos(u*83-t*5)
   verts.append((x,side*(depth+ripple+.035),z+.02*math.sin(u*9)*math.sin(t*math.pi)))
 off=0 if side==-1 else (nx+1)*(nz+1)
 for j in range(nz):
  for i in range(nx):
   a=off+j*(nx+1)+i;f=(a,a+1,a+nx+2,a+nx+1);faces.append(f if side==-1 else f[::-1])
mesh=bpy.data.meshes.new('Bag draped film');mesh.from_pydata(verts,[],faces);mesh.update();o=bpy.data.objects.new('Packaging',mesh);bpy.context.collection.objects.link(o);finish(o,'Packaging',film,'packaging')
for p in mesh.polygons:p.use_smooth=True
# Thin seals and restrained gathered creases.
for sign in [-1,1]:
 pts=[]
 for j in range(29):
  t=j/28;width=1.45*(.91+.09*math.sin(t*math.pi)) if t<.8 else 1.45*(1-(t-.8)*.65)
  pts.append((sign*width,0,.18+t*3))
 curve('Bag_EdgeSeal',pts,seam,.021)
curve('Bag_BottomSeal',[(-1.3,0,.20),(0,-.025,.17),(1.3,0,.20)],seam,.022)
# Non-graphic stylised raw steak, with rounded irregular contour and subtle fat edge.
N=72
cont=[]
for i in range(N):
 a=2*math.pi*i/N;r=1+.08*math.sin(a*3)+.05*math.cos(a*5);cont.append((math.cos(a)*1.07*r,math.sin(a)*.61*r))
v=[]
for y in [-.29,.25]:
 for x,z in cont:v.append((x,y,1.06+z))
f=[tuple(range(N-1,-1,-1)),tuple(range(N,2*N))]
for i in range(N):f.append((i,(i+1)%N,(i+1)%N+N,i+N))
mesh=bpy.data.meshes.new('Steak solid');mesh.from_pydata(v,[],f);mesh.update();o=bpy.data.objects.new('Meat',mesh);bpy.context.collection.objects.link(o);finish(o,'Meat',meatmat,'meat');bpy.context.view_layer.objects.active=o;o.select_set(True)
be=o.modifiers.new('Soft organic edges','BEVEL');be.width=.14;be.segments=5;bpy.ops.object.modifier_apply(modifier=be.name);o.select_set(False)
for p in o.data.polygons:p.use_smooth=True
# Several vein-like gentle marbling strokes, not dense/graphic.
for i in range(9):
 x=-.85+i*.2;zz=.69+random.random()*.15
 pts=[(x+.045*math.sin(j*.8+i),-.304,zz+j*.057) for j in range(random.randint(6,12))]
 curve('Meat_Marbling',pts,fat,.007+random.random()*.005)
# Save render studio in blend, exclude from glb through selection.
assets=[o for o in bpy.context.scene.objects if o.type=='MESH']
for o in assets:o.select_set(True)
bpy.ops.export_scene.gltf(filepath=os.path.join(OUT,'freshclip.glb'),export_format='GLB',use_selection=True,export_extras=True,export_yup=True)
bpy.ops.object.select_all(action='DESELECT')
floor=mat('Studio sand',(.77,.79,.74),.9);box('Studio_Floor',(0,0,-.04),(200,200,.06),floor,.0)
world=bpy.context.scene.world;world.use_nodes=True;world.node_tree.nodes['Background'].inputs[0].default_value=(.75,.79,.73,1);world.node_tree.nodes['Background'].inputs[1].default_value=.65
for name,loc,energy,size in [('Key',(-4,-5,8),1100,5),('Fill',(5,-2,5),700,4),('Rim',(0,4,6),1200,3)]:
 bpy.ops.object.light_add(type='AREA',location=loc);o=bpy.context.object;o.name=name;o.data.energy=energy;o.data.shape='DISK';o.data.size=size;o.rotation_euler=(Vector((0,0,2))-o.location).to_track_quat('-Z','Y').to_euler()
bpy.ops.object.camera_add(location=(5,-9,6));cam=bpy.context.object;cam.rotation_euler=(Vector((0,0,2))-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO';cam.data.ortho_scale=5.4;bpy.context.scene.camera=cam
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=40;scene.render.resolution_x=1200;scene.render.resolution_y=1200;scene.render.resolution_percentage=100;scene.view_settings.view_transform='AgX';scene.render.image_settings.file_format='PNG'
bpy.ops.wm.save_as_mainfile(filepath=os.path.join(OUT,'freshclip.blend'))
scene.render.filepath=os.path.join(OUT,'exterior.png');bpy.ops.render.render(write_still=True)
for o in assets:
 if o.name.startswith('Shell'):o.location.z+=.95
cam.location=(4,-7,8);cam.rotation_euler=(Vector((0,0,2.7))-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.ortho_scale=5.8
scene.render.filepath=os.path.join(OUT,'internal.png');bpy.ops.render.render(write_still=True)
with open(os.path.join(OUT,'mesh-index.json'),'w') as f:json.dump([{'name':o.name,'component':o.get('component'),'blender_location':list(o.location)} for o in assets],f,indent=2)
