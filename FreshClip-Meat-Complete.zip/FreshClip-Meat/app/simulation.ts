// Presentation mappings only. No chemical kinetics or calibrated food-safety thresholds.
export function getSimulation(raw:number){
 const p=Math.max(0,Math.min(100,raw));
 const stops=[[48,151,94],[224,170,47],[204,66,53]];
 const t=p<=50?p/50:(p-50)/50,a=stops[p<=50?0:1],b=stops[p<=50?1:2];
 const rgb=a.map((v,i)=>Math.round(v+(b[i]-v)*t));
 const state=p<35?'Fresh':p<70?'Monitor':'Warning';
 return {state,color:`rgb(${rgb.join(',')})`,response:(p/100).toFixed(2),time:(p/10).toFixed(1),output:p<35?'Green':p<70?'Yellow':'Red',particles:Math.round(12+p*1.28),description:p<35?'Low simulated spoilage response.':p<70?'An increasing simulated response.':'High simulated response; a warning signal.'};
}
export const components=[
{id:'sensor',num:'01',name:'VOC sensing region',short:'Sense',caption:'Volatiles reach the inlet',description:'A proposed protected inlet exposes the sensing region to package headspace without direct meat contact.'},
{id:'control',num:'02',name:'Comparator electronics',short:'Compare',caption:'Response drives a state',description:'A conceptual comparator converts the sensor response into an indicator state; real thresholds require calibration.'},
{id:'indicator',num:'03',name:'RGB indicator',short:'Indicate',caption:'A visible colour signal',description:'An RGB light presents the simulated response as a continuous green-to-yellow-to-red colour change.'},
{id:'battery',num:'04',name:'CR2032-style battery',description:'A replaceable coin cell illustrates the power source; usable lifetime and sensor power demands need testing.'},
{id:'temperature',num:'05',name:'Temperature sensor',description:'A temperature sensor represents environmental monitoring; this demo holds its synthetic input at 4 °C.'},
{id:'pcb',num:'06',name:'Circuit board',description:'A simplified PCB links the proposed sensing, comparator, indicator, and power components.'},
{id:'shell',num:'07',name:'Polypropylene casing',description:'A reusable rounded shell represents the food-grade polypropylene enclosure proposed in the document.'},
{id:'hinge',num:'08',name:'Clamp and hinge',description:'A hinged jaw presses the package neck against a sealing surface; real seal performance must be tested.'},
{id:'button',num:'09',name:'Reset button',description:'A control button represents resetting the device between uses; resetting cannot make deteriorated food fresh.'}
];
