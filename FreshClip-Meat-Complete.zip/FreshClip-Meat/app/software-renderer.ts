import * as THREE from 'three';
/** Canvas-based projection of the same GLB meshes when WebGL is unavailable.
 * Uses a painter's algorithm and diffuse face shading; no optical simulation.
 */
export class SoftwareRenderer {
 domElement=document.createElement('canvas');shadowMap={enabled:false,type:0};toneMapping=0;toneMappingExposure=1;
 private ctx=this.domElement.getContext('2d')!;private width=1;private height=1;private ratio=1;
 setPixelRatio(r:number){this.ratio=Math.min(r,1.3)}
 setSize(w:number,h:number){this.width=w;this.height=h;this.domElement.width=w*this.ratio;this.domElement.height=h*this.ratio;this.domElement.style.width=w+'px';this.domElement.style.height=h+'px'}
 render(scene:THREE.Scene,camera:THREE.Camera){
  const ctx=this.ctx,w=this.width,h=this.height;ctx.setTransform(this.ratio,0,0,this.ratio,0,0);ctx.fillStyle='#f0f2ee';ctx.fillRect(0,0,w,h);scene.updateMatrixWorld();camera.updateMatrixWorld();
  const pv=new THREE.Matrix4().multiplyMatrices(camera.projectionMatrix,camera.matrixWorldInverse);const mv=new THREE.Matrix4();const nm=new THREE.Matrix3();const v=new THREE.Vector3(),n=new THREE.Vector3();const light=new THREE.Vector3(-.3,.85,.45).normalize();
  type Face={xy:number[];z:number;c:string;alpha:number;tex?:CanvasImageSource;uv?:number[]};const faces:Face[]=[];
  const base=new THREE.Vector3(0,.01,0).project(camera);const sw=Math.min(w*.3,180);const grd=ctx.createRadialGradient((base.x+1)*w/2,(1-base.y)*h/2,2,(base.x+1)*w/2,(1-base.y)*h/2,sw);grd.addColorStop(0,'rgba(70,85,60,.16)');grd.addColorStop(1,'rgba(70,85,60,0)');ctx.save();ctx.translate(0,(1-base.y)*h/2*.65);ctx.scale(1,.35);ctx.fillStyle=grd;ctx.fillRect(0,0,w,h*3);ctx.restore();
  scene.traverseVisible(obj=>{
   if(!(obj instanceof THREE.Mesh)||!obj.parent||obj.parent===scene||obj instanceof THREE.SkinnedMesh)return;
   const mat=(Array.isArray(obj.material)?obj.material[0]:obj.material) as THREE.MeshStandardMaterial;
   if(!mat.color)return;const pos=obj.geometry.attributes.position,normal=obj.geometry.attributes.normal,uv=obj.geometry.attributes.uv,idx=obj.geometry.index;const len=idx?idx.count:pos.count;
   mv.multiplyMatrices(pv,obj.matrixWorld);nm.getNormalMatrix(obj.matrixWorld);
   const projected=new Float32Array(pos.count*3);
   for(let j=0;j<pos.count;j++){v.fromBufferAttribute(pos,j).applyMatrix4(mv);projected[j*3]=(v.x+1)*w/2;projected[j*3+1]=(1-v.y)*h/2;projected[j*3+2]=v.z;}
   const clr=mat.color.clone().convertLinearToSRGB();
   for(let j=0;j<len;j+=3){const a=idx?idx.getX(j):j,b=idx?idx.getX(j+1):j+1,c=idx?idx.getX(j+2):j+2;const xy=[projected[a*3],projected[a*3+1],projected[b*3],projected[b*3+1],projected[c*3],projected[c*3+1]];
    const area=(xy[2]-xy[0])*(xy[5]-xy[1])-(xy[3]-xy[1])*(xy[4]-xy[0]);if(area>0||Math.abs(area)<.08)continue;
    if(normal){n.fromBufferAttribute(normal,a).add(v.fromBufferAttribute(normal,b)).add(v.fromBufferAttribute(normal,c)).applyMatrix3(nm).normalize()}else n.set(0,1,0);
    const shade=.76+.24*Math.max(0,n.dot(light));const color=`rgb(${Math.round(clr.r*255*shade)},${Math.round(clr.g*255*shade)},${Math.round(clr.b*255*shade)})`;
    const f:Face={xy,z:(projected[a*3+2]+projected[b*3+2]+projected[c*3+2])/3,c:color,alpha:mat.opacity};
    if(mat.map?.image&&uv){f.tex=mat.map.image as CanvasImageSource;f.uv=[uv.getX(a),1-uv.getY(a),uv.getX(b),1-uv.getY(b),uv.getX(c),1-uv.getY(c)]}faces.push(f);
   }
  });
  faces.sort((a,b)=>b.z-a.z);
  for(const f of faces){const x=f.xy;ctx.globalAlpha=f.alpha;ctx.beginPath();ctx.moveTo(x[0],x[1]);ctx.lineTo(x[2],x[3]);ctx.lineTo(x[4],x[5]);ctx.closePath();ctx.fillStyle=f.c;ctx.fill();
   if(f.tex&&f.uv){const tex=f.tex as HTMLImageElement,tw=tex.width,th=tex.height,u=f.uv.map((n,i)=>n*(i%2?th:tw));const du1=u[2]-u[0],dv1=u[3]-u[1],du2=u[4]-u[0],dv2=u[5]-u[1],den=du1*dv2-du2*dv1;if(Math.abs(den)<.001)continue;const a=((x[2]-x[0])*dv2-(x[4]-x[0])*dv1)/den,b=((x[3]-x[1])*dv2-(x[5]-x[1])*dv1)/den,c=((x[4]-x[0])*du1-(x[2]-x[0])*du2)/den,d=((x[5]-x[1])*du1-(x[3]-x[1])*du2)/den;ctx.save();ctx.clip();ctx.transform(a,b,c,d,x[0]-a*u[0]-c*u[1],x[1]-b*u[0]-d*u[1]);ctx.drawImage(tex,0,0);ctx.restore();}
   else if(f.alpha===1){ctx.strokeStyle=f.c;ctx.lineWidth=.5;ctx.stroke()}
  }ctx.globalAlpha=1;
  scene.traverseVisible(obj=>{if(obj instanceof THREE.Points){const p=obj.geometry.attributes.position,m=obj.material as THREE.PointsMaterial;ctx.fillStyle=m.color.getStyle();ctx.globalAlpha=.45;for(let i=0;i<obj.geometry.drawRange.count;i++){v.fromBufferAttribute(p,i).applyMatrix4(obj.matrixWorld).project(camera);ctx.beginPath();ctx.arc((v.x+1)*w/2,(1-v.y)*h/2,1.1,0,Math.PI*2);ctx.fill()}ctx.globalAlpha=1}if(obj instanceof THREE.Box3Helper){const b=obj.box,verts=[];for(let i=0;i<8;i++)verts.push(new THREE.Vector3(i&1?b.max.x:b.min.x,i&2?b.max.y:b.min.y,i&4?b.max.z:b.min.z).project(camera));ctx.strokeStyle='#6b965b';ctx.lineWidth=1;ctx.beginPath();for(let i=0;i<8;i++)for(const bit of [1,2,4])if(!(i&bit)){const a=verts[i],b=verts[i|bit];ctx.moveTo((a.x+1)*w/2,(1-a.y)*h/2);ctx.lineTo((b.x+1)*w/2,(1-b.y)*h/2)}ctx.stroke()}});
 }
 dispose(){}
}
