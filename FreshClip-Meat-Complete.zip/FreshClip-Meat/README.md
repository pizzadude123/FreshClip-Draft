# FreshClip Meat — complete project

Interactive 3D product concept. All simulated spoilage values are synthetic and not experimentally calibrated. The indicator does not determine food safety.

## Run the application
Requires Node.js 22.13 or later. In this folder run:

```sh
npm ci
npm run dev
```

Production build: `npm run build`. Preview that build: `npm run preview`.
The included dist/ folder is the already-built static application; serve it using an HTTP server, rather than opening index.html directly.

## Included files
- app/, components/, lib/, main.tsx: complete application source.
- public/models/freshclip.glb: portable 3D model with embedded textures.
- model-source/freshclip.blend: editable Blender 4.3 scene, packed textures and studio lighting.
- model-source/*.py: geometry generation and Blender import scripts.
- renders/: exterior and internal rendered images.
- package.json and package-lock.json: dependencies and reproducible installation.
- vercel.json and netlify.toml: hosting configuration.
- original-workspace/: original framework version and supporting source files. The portable application above is the recommended deployment version.

Dependency folders, caches, credentials and temporary runtime files are excluded. Dependencies are restored with npm ci.

## Controls
Drag to orbit; scroll or use buttons to zoom. Exterior/Internal switches the casing view. Select components in the model or the component list. The slider updates progress, response, particles, colour and elapsed demo units. Start/Pause, Reset and Auto Demo control playback.

## Assumptions and validation
The supplied FreshClip presentation proposes a polypropylene clip, headspace sensing, temperature sensor, comparator electronics, CR2032-style cell, reset button and colour indicator. Geometry, protected inlet, component placement and sealing surfaces are prototype design assumptions. The battery is represented as replaceable, not rechargeable. No battery-life claim is made.

Progress is 0–100%; response is progress/100; elapsed storage is progress/10 arbitrary units, not hours. The 35% and 70% state boundaries are presentation choices, not calibrated thresholds. Temperature is held at a synthetic 4 °C. Particle paths illustrate transport, not molecular physics.

Real validation is required for sensor selection, meat-specific calibration, humidity/temperature interference, sealing, cleaning, food-contact suitability, battery power demand, and comparisons against established food-quality measurements.

## Verification status
The portable production build passed TypeScript checking and Vite compilation. Full browser interaction testing and public deployment verification are not yet complete. WebGL is the primary renderer; the Canvas fallback has simpler shading.
